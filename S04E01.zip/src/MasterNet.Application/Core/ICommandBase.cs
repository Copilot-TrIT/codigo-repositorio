
namespace MasterNet.Application.Core;

public interface ICommandBase
{}