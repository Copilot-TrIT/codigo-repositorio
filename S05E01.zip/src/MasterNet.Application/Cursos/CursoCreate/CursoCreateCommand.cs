// Command
// CommandHandler

using FluentValidation;
using MasterNet.Application.Core;
using MasterNet.Application.Interfaces;
using MasterNet.Domain;
using MasterNet.Domain.Abstractions;
using MediatR;

namespace MasterNet.Application.Cursos.CursoCreate;

public class CursoCreateCommand
{
    public record CursoCreateCommandRequest(CursoCreateRequest cursoCreateRequest)
    : IRequest<Result<Guid>>, ICommandBase;


    internal class CursoCreateCommandHandler : IRequestHandler<CursoCreateCommandRequest, Result<Guid>>
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IPhotoService _photoService;

        public CursoCreateCommandHandler(IUnitOfWork unitOfWork, IPhotoService photoService)
        {
            _unitOfWork = unitOfWork;
            _photoService = photoService;
        }

        public async Task<Result<Guid>> Handle(CursoCreateCommandRequest request, CancellationToken cancellationToken)
        {
            var cursoId = Guid.NewGuid();
            var curso = new Curso
            {
                Id = cursoId,
                Titulo = request.cursoCreateRequest.Titulo,
                Descripcion = request.cursoCreateRequest.Descripcion,
                FechaPublicacion = request.cursoCreateRequest.FechaPublicacion
            };

            if (request.cursoCreateRequest.Foto is not null)
            {
                var photoUploadResult = await _photoService.AddPhoto(request.cursoCreateRequest.Foto);
                var photo = new Photo
                {
                    Id = Guid.NewGuid(),
                    Url = photoUploadResult.Url,
                    PublicId = photoUploadResult.PublicId,
                    CursoId = cursoId
                };
                curso.Photos = new List<Photo> { photo };
            }

            if (request.cursoCreateRequest.InstructorId is not null)
            {
                var instructor = await _unitOfWork.Repository<Instructor>().GetByIdAsync(request.cursoCreateRequest.InstructorId.Value);
                if (instructor is null)
                {
                    return Result<Guid>.Failure("No se encontr� el instructor");
                }
                curso.Instructores = new List<Instructor> { instructor };
            }

            if (request.cursoCreateRequest.PrecioId is not null)
            {
                var precio = await _unitOfWork.Repository<Precio>().GetByIdAsync(request.cursoCreateRequest.PrecioId.Value);
                if (precio is null)
                {
                    return Result<Guid>.Failure("No se encontr� el precio");
                }
                curso.Precios = new List<Precio> { precio };
            }

            await _unitOfWork.Repository<Curso>().AddAsync(curso);
            var resultado = await _unitOfWork.SaveChangesAsync();

            return resultado ? Result<Guid>.Success(curso.Id) : Result<Guid>.Failure("No se pudo insertar el curso");
        }
    }


    public class CursoCreateCommandRequestValidator
    : AbstractValidator<CursoCreateCommandRequest>
    {
        public CursoCreateCommandRequestValidator()
        {
            RuleFor(x => x.cursoCreateRequest).SetValidator(new CursoCreateValidator());
        }

    }

}
